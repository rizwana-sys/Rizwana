package sample;

public class Sample {
	Sample()
	{
		System.out.println("red");//Default//
	}
	Sample(String  a)
	{
		System.out.println("Inside"+a);//parametarized//
	}
	public static void main(String [] args)
	{
Sample obj1=new Sample();
Sample obj2=new Sample("blue");
		
	}

}
