package marker;
import java.util.Scanner;
public class Marker 
	{
	 int color;
	 void checkc()
	 {
	Scanner scn=new Scanner(System.in);
	System.out.println("Enter color");
    color=scn.nextInt();
    	switch(color)
    	{
    	case 0:System.out.println("Red color");
    	       break;
    	case 2:System.out.println("blue color");
    	       break;
    	case 3:System.out.println("Green color");
    	       break;
    	case 4:System.out.println("black color");
    	       break;
    	case 5:System.out.println("pink color");
    	      break;
    	default:System.out.println("no color");
	}
    	
}
	 public static void main(String [] args)
	 {
		 Marker c1=new Marker();
		 c1.checkc();
}
}