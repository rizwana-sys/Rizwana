package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sel4 {
public void login(String Eid,String pass)
{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	 WebDriver dr=new ChromeDriver();
	 dr.get("http://demowebshop.tricentis.com");
	 dr.findElement(By.linkText("Log in")).click();
	 dr.findElement(By.id("Email")).sendKeys(Eid);
	dr.findElement(By.id("Password")).sendKeys(pass);
	 dr.findElement(By.xpath("//input[@value='Log in']")).click();
}
	 public static void main(String[] args)
	 {
		 sel4 a=new sel4();
	   a.login("rizzu5399@gmail.com","Rizwana@19");	 
	
}
}
