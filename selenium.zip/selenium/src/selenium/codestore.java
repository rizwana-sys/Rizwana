package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class codestore {


	public static void main(String [] args)
	{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr=new ChromeDriver();
   dr.get("http://examples.codecharge.com//store/Default.php");
   String Title=dr.getTitle();
   System.out.println(Title);
   String T="Online Bookstore";
   if(Title.compareTo(T)==0)
	   System.out.println("correct title");
   else
	   System.out.println("Wrong title");
   
   dr.findElement(By.xpath("//option[@value='2']")).click();
   dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
		String text=dr.findElement(By.xpath("//a[(text()='Web Database Development')]")).getText();
		  String txt="Web Database Development";
if(text.compareTo(txt)==0)
	System.out.println("Text displayed");
else
	System.out.println("Wrong");
dr.findElement(By.xpath("//a[(text()='Web Database Development')]")).click();

String price=dr.findElement(By.xpath("//td[@colspan='2']")).getText();
  System.out.println(price);
   
  dr.findElement(By.xpath("//input[@value='1']")).clear();
   dr.findElement(By.xpath("//input[@value='1']")).sendKeys("2");
   dr.findElement(By.xpath("//input[@name='Insert1']")).click();
   dr.findElement(By.xpath("//input[@name='Submit']")).click();
   String total=dr.findElement(By.xpath("//td[@align='right'][3]")).getText();
   System.out.println("Total:"+total);
   String chtotal=total.substring(1,total.length());
   System.out.println(chtotal);
   
   String quant=dr.findElement(By.xpath("//tr[@class='Row']//child::td/input")).getAttribute("value");
   System.out.println("Quantity:"+quant);
   float p1=Float.parseFloat(total);
   float p2=Float.parseFloat(chtotal);
   float Q=Float.parseFloat(quant);
   
   float tp=p1*Q;
   System.out.println("Total price:"+tp);
   if(tp==p2)
	   System.out.println("correct");
   else
	   System.out.println("Wrong");
   
   
   
	}
}
