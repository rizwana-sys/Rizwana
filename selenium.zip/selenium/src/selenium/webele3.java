package selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class webele3 {
	String s1;
	public void  extract()
	{
		int p=s1.indexOf(":",0);
		 System.out.println(p);
		 
		 int p1=s1.indexOf("A",0);
		 System.out.println(p1);
		 
		 
		 String p2=s1.substring(p+1,p1-1);
		 System.out.println(s1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		 WebDriver dr=new ChromeDriver();
		 dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
 
		 
		 List rb=dr.findElements(By.name("gender"));
		 ((WebElement) rb.get(0)).click();
		 
		 List rb1=dr.findElements(By.name("ageGroup"));
		 ((WebElement) rb1.get(1)).click();
		 
		 dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/button")).click();
		 
		String  s1=dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/p[2]")).getText();
	 System.out.println(s1);
	}
	 
	 webele3 obj1=new webele3();
	 obj1.extract();
		 
		
		 
	
	}

