package selenium;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  
  public void t1() {
	  System.out.println("test 1");
  }
 @Test
 
 public void t2()
 {
	 System.out.println("test 2");
 }
 @Test
 
 public void t3()
 {
	 System.out.println("test 3");
 }
  
}
