package selenium;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BM
{
  @BeforeMethod
  public void BM() {
	  System.out.println("in before method");
  }
  @AfterMethod
  public void After_method()
  {
	  System.out.println("After method");
  }
  @BeforeClass
  
  public void Before_class()
  {
	  System.out.println("in before class");
  }
  
  @AfterClass
	  public void After_class()
	  {
		  System.out.println("in after class");
	  }
  
	 

	  
	  
	  
  @Test
  public void t1()
  {
	  System.out.println("t1 done");
  }
  @Test
  public void t2()
  {
	  System.out.println("t2 done");
  }
  @Test
  public void t3()
  
  {
	  System.out.println("t3 done");
  }
}

