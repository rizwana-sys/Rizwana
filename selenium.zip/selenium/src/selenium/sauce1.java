package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sauce1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
	dr.findElement(By.xpath("//input[@type='text']")).sendKeys("standard_user");
	dr.findElement(By.xpath("//input[@type='password']")).sendKeys("secret_sauce");
	dr.findElement(By.xpath("//input[@type='submit']")).click();
	
	
	}

}
