package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class verfication {
	public static void main(String [] args)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		dr.findElement(By.xpath("//input[@name='user_login']")).sendKeys("rizzu5399@gmail.com");
	dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("rizwana@19");
	dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("shaik");
	dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("Rizwana");
	dr.findElement(By.xpath("//input[@name='email']")).sendKeys("rizzu5399@gmail.com");
	dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("prashanthnagar extension");
	dr.findElement(By.xpath("//input[@name='address2']")).sendKeys("aditya junior college");
	dr.findElement(By.xpath("//input[@name='address3']")).sendKeys("madanapalle");
	dr.findElement(By.xpath("//input[@name='city']")).sendKeys("madanapalle");
	dr.findElement(By.xpath("//option[@value='7']")).click();
	dr.findElement(By.xpath("//input[@name='zip']")).sendKeys("12345");
	dr.findElement(By.xpath("//option[@value='112']")).click();
	dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("8106849519");
	dr.findElement(By.xpath("//option[contains(text(),'English')]")).click();
	dr.findElement(By.xpath("//option[contains(text(),'18-24')]")).click();
	dr.findElement(By.xpath("//option[(text()='Female')]")).click();
	dr.findElement(By.xpath("//option[(text()='Graduate School')]")).click();
	dr.findElement(By.xpath("//option[(text()='under $25,000')]")).click();
	dr.findElement(By.xpath("//textarea[@name='note']")).sendKeys("I AM Rizwana");
	dr.findElement(By.xpath("//input[@value='Register']")).click();
	dr.findElement(By.xpath("//img[@src='images/home.gif']")).click();
	dr.findElement(By.xpath("//input[@maxlength='20']")).sendKeys("Rizwana");
	String S1=dr.findElement(By.xpath("//input[@maxlength='20']")).getText();
	dr.findElement(By.xpath("//input[@value='Search']")).click();
	
	String S2="Rizwana";
	if(S1==S2)
	{
		System.out.println("successful");
	}
	else
	{
		System.out.println("unsuccessful");
	}
	
	//dr.findElement(By.xpath("//input[@value='Search']")).click();
	
	
	
	
	
		
	}

}
