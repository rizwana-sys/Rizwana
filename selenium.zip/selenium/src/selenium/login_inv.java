package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_inv {
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
	 dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("rizzu5399@gmail.com"); 
		dr.findElement(By.id("Password")).sendKeys("rizwana@19");
		dr.findElement(By.xpath("//input[@value='Log in1']")).click();
		dr.findElement(By.xpath("//div[@class='validation-summary-errors']"));
		dr.findElement(By.xpath("//span[@for='Email']"));
	}

}
