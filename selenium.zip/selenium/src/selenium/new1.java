package selenium;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class new1 {
	private static TimeUnit timeUnit;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		 WebDriver dr=new ChromeDriver();
		 dr.get("http://demowebshop.tricentis.com/accessories");
	
		 dr.findElement(By.linkText("Log in1")).click();
		Object SECONDS;
		dr.manage().timeouts().implicitlyWait(10,timeUnit).(SECONDS);
}
}
