package selenium;

public class classjava {

	public void login() {
		System.out.println("login successful");
	}

}
