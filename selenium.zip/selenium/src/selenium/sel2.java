package selenium;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sel2 {
	public static void main(String[] args) {
		System.out.println("Enter a num:");
		Scanner scn=new Scanner(System.in);
		int s=scn.nextInt();
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	 WebDriver dr=new ChromeDriver();
	 dr.get("http://demowebshop.tricentis.com");
	 dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("rizzu5399@gmail.com"); 
			dr.findElement(By.id("Password")).sendKeys("Rizwana@19");
			dr.findElement(By.xpath("//input[@value='Log in']")).click();
	     dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]/a")).getText();
	     dr.findElement(By.xpath("//div[@class='header-menu']//child::li[1]/a")).click();
	     
	     
	     for(int r=1;r<=6;r++)
	     {
	     	if(r==s)
	     	{
	     		 dr.findElement(By.xpath("//div[@class='item-box']["+r+"]")).click();
	     		 dr.findElement(By.xpath("//input[@value='Add to cart']")).click();
	     	}
	     }
	     String str= dr.findElement(By.xpath("//a[@class='product-name']")).getText();
	     System.out.println(str);
	   String str1= dr.findElement(By.xpath("//td[@class='unit-price nobr']//child::span[2]")).getText();
	   System.out.println(str1);
	     
	   dr.findElement(By.xpath("//tr[@class='cart-item-row']//child::td[2]")).click();
	     		 dr.findElement(By.xpath("//div@class='common-buttons']//child::input")).click();
	        }
}
