package selenium;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class sel3 {
	
	public static void main(String[] args) {

	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	 WebDriver dr=new ChromeDriver();
	 dr.get("http://demowebshop.tricentis.com/books");
	 String xp="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/label",
			 xp1 = "/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[3]/label";
	 
	 WebElement we;
	 WebDriverWait wt=new WebDriverWait(dr,10);
	 we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp1)));
	 we.click();
}
}
