package selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class readlogin {
		public String readexcel(String filename,String sheetname,int r,int c){
			String S=null;
				File f=new File(filename);{
					FileInputStream fis;
					try {
						fis = new FileInputStream(f);
						XSSFWorkbook Wb=new XSSFWorkbook(fis);
						XSSFSheet sh=Wb.getSheet(sheetname);
						XSSFRow row=sh.getRow(r);
						XSSFCell cell=row.getCell(c);
						  S = cell.getStringCellValue();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();		}}
				return S;}
			public void login(String Eid,String pass){
				System.setProperty("Webdriver.chrome.driver", "chromedriver_v79.exe");
				WebDriver dr=new ChromeDriver();
				 dr.get("http://demowebshop.tricentis.com");
				 dr.findElement(By.linkText("Log in")).click();
				 dr.findElement(By.id("Email")).sendKeys(Eid);
				dr.findElement(By.id("Password")).sendKeys(pass);
				 dr.findElement(By.xpath("//input[@value='Log in']")).click();}
		public static void main(String[] args)
		{
			readlogin l =new readlogin();
		    String a =l.readexcel("C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\login.xlsx", "sheet1", 0,0);
		    System.out.println(a);
		    String b=l.readexcel("C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\login.xlsx", "sheet1", 1, 0);
		    System.out.println(b);}}

