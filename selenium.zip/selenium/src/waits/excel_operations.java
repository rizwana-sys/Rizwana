package waits;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {

	
	String sheetname="Sheet1";
	String filename="C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\kwd.xlsx";
	public String read_excel(int row,int col)
	{
		String s=null;
	try
	{
		File f=new File(filename);
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet(sheetname);
		XSSFRow r=sh.getRow(row);
		XSSFCell c=r.getCell(col);
		s=c.getStringCellValue();
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
		return(s);
	}
	
	
}
