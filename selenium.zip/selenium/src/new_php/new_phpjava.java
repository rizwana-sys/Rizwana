package new_php;

public class new_phpjava {

	
	
	
	
	
}
