package new_php;

import org.testng.annotations.Test;

public class testngphp {
  @Test
  public void f() {
  }
}
