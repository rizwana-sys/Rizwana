package sel19_20;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class asserts {
  @Test
  public void t1()
  {
	  String ex="banglore",ac="banglore";
	  System.out.println("in test method t1");
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ex,ac);
	  sa.assertAll();
  }
	
@Test
public void t2()
{
	String ex="banglore",ac="banglore1"  ;
	System.out.println("in test method t2");
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(ex,ac);
	sa.assertAll();
}
	  
  }