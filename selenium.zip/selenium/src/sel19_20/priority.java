package sel19_20;

import org.testng.annotations.Test;

public class priority {
	
  @Test(priority=5)
  
  public void z() {
	  System.out.println("t1 runs");
  }
  @Test(priority=10)
  
public void c()
{
	System.out.println("t2 runs");
}
  
  @Test(priority=1)
public void a()
{
	System.out.println("t3 runs");
}
}