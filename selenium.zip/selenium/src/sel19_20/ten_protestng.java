package sel19_20;

import org.testng.annotations.Test;

public class ten_protestng {
  @Test
  public void f() {
	  
	  
	  
  }
}
