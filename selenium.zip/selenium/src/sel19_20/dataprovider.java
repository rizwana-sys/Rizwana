package sel19_20;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataprovider {
  @Test(dataProvider="login_data")
  public void login(String eid,String pwd,String exp_res)
  {
	  System.out.println("email id:"+eid+"pwd:"+pwd+"expected res:"+exp_res);
  }
  @DataProvider(name="login_data")
  
  public String[][] provide_data()
  {
	  String[][] data={
			  {"riz","r1","correct"},
			  {"sul","s1","correct"},
			  {"riz","rr1","wrong"}
			  };
 
  return data;
}
}
  
  
  
  
 
