package sel21_21;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import sel20_20.dataproviderjava;

public class data_providerjavangReg {
	data_providerjavangReg obj=new data_providerjavangReg();

			static String sheetname = "login";
			public  static String file name="C:\\Users\\BLTuser.BLT0204\\Desktop\\ctsdata.xlsx";
			public static String[][] testdata;
			public static int r_no,c_no;
			public static void get_Test_data(){
				testdata=new String[2][3];
				int c;String s=null,s1=null,s2=null;
				for(r_no=0;r_no<=1;r_no++)
				{
					try
					{
				System.out.println("in get test data row="+ r_no);
				String filename;
				File f= new File(filename);
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sheet =wb.getSheet(sheetname);
				XSSFRow row=sheet.getRow(r_no);
				XSSFCell cell1=row.getCell(0);
				testdata[r_no][0]=cell1.getStringCellValue();
				System.out.println("row 1:"+testdata[r_no][0]);
				XSSFCell cell2=row.getCell(1);
				testdata[r_no][1]=cell2.getStringCellValue();
				System.out.println("row 1:"+testdata[r_no][1]);
				XSSFCell cell3=row.getCell(2);
				testdata[r_no][2]=cell3.getStringCellValue();
				System.out.println("row 1:"+testdata[r_no][2]);
				XSSFCell cell4=row.getCell(3);
				testdata[r_no][3]=cell3.getStringCellValue();
				System.out.println("row 1:"+testdata[r_no][3]);
				XSSFCell cell5=row.getCell(4);
				testdata[r_no][4]=cell3.getStringCellValue();
				System.out.println("row 1:"+testdata[r_no][4]);
				
							
			}
					catch(FileNotFoundException e){
						e.printStackTrace();
						}
					catch(IOException e)
					{
						e.printStackTrace();
					}
				}
			}

			public void register(String f_name,String l_name,String email,String pwd,String confirm_pwd)
			{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//div[@class='header-links']//child::a")).click();
	dr.findElement(By.xpath("//input[@name='Gender']")).click();
	dr.findElement(By.xpath("//input[@name='FirstName']")).sendKeys(f_name);
	dr.findElement(By.xpath("//input[@id='LastName']")).sendKeys(l_name);
	dr.findElement(By.xpath("//input[@id='Email']")).sendKeys(email);
	dr.findElement(By.xpath("//input[@name='Password']")).sendKeys(pwd);
	dr.findElement(By.xpath("//input[@name='ConfirmPassword']")).sendKeys(confirm_pwd);
	dr.findElement(By.xpath("//input[@value='Register']")).click();
		}
	}

