package sel21_21;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GEID_HUB {
	WebDriver dr;
	String autURL,nodeURL;
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		autURL="http://demowebshop.tricentis.com";
		nodeURL="http://192.168.1.12:5566/wd/hub";
	DesiredCapabilities cap=DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
	dr=new RemoteWebDriver(new URL(nodeURL),cap);
	}
@Test
public void test()
{
	dr.get(autURL);
}

}
