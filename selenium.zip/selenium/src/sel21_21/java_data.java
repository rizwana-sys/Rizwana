package sel21_21;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class java_data {
	public void register(String f_name,String l_name,String email,String pwd,String confirm_pwd)
	{
System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
WebDriver dr=new ChromeDriver();
dr.get("http://demowebshop.tricentis.com");
dr.findElement(By.xpath("//div[@class='header-links']//child::a")).click();
dr.findElement(By.xpath("//input[@name='Gender']")).click();
dr.findElement(By.xpath("//input[@name='FirstName']")).sendKeys(f_name);
dr.findElement(By.xpath("//input[@id='LastName']")).sendKeys(l_name);
dr.findElement(By.xpath("//input[@id='Email']")).sendKeys(email);
dr.findElement(By.xpath("//input[@name='Password']")).sendKeys(pwd);
dr.findElement(By.xpath("//input[@name='ConfirmPassword']")).sendKeys(confirm_pwd);
dr.findElement(By.xpath("//input[@value='Register']")).click();
	}
	public static void main(String[] args)
	{
	public static String filename="C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\data.xlsx";
	{
		
	}
}
