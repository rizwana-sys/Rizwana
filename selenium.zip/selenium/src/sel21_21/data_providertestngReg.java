package sel21_21;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import sel20_20.Dataprov_excel_cls;

public class data_providertestngReg extends  data_providerjavangReg{
  @Test(dataProvider="register")
  public void register(String f_name,String l_name,String email,String pwd,String confirm_pwd)
  {
	  System.out.println("first name:"+f_name+"last name:"+l_name+"email:"+email+"password:"+pwd+"confirm password:"+confirm_pwd);
  
	  test=new Dataprov_excel_cls();
		String a_eid=test.register(email,pwd);
		System.out.println("act_res:"+a_eid);
	   System.out.println("ex_res:"+a_eid);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(a_eid, exp_eid);
		sa.assertAll();
  }
  @DataProvider
  (name="register")
  
  public String[][] provide_data()
  {
return data;
  }
}


