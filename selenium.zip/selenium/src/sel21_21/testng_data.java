package sel21_21;

import org.testng.annotations.Test;

public class testng_data {
  @Test
  public void f() {
  }
}
