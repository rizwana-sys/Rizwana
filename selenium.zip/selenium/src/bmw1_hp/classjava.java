package bmw1_hp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class classjava {
	WebDriver dr;
	public classjava(WebDriver dr)
	{
		this.dr=dr;
	}
	public WebDriver launchbrowser(String browser,String url)
	{
		if(browser.contains("CHROME"))
		{
			System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			dr=new ChromeDriver();
			}
		else if(browser.contains("FIREFOX"))
		{
			System.setProperty("Webdriver.gecko.driver","geckodriver.exe");
			dr=new FirefoxDriver();
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
		return dr;
	}

	public int page1()
	{
dr.findElement(By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[1]/div/div[1]/div[1]/div/div[1]/a")).click();
dr.findElement(By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[1]/div/nav/div/div/div[4]/a")).click();	
dr.findElement(By.xpath("//*[@id=\"the-top-navigation\"]/div/div/div/div[1]/div/div[1]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/img")).click();
dr.findElement(By.xpath("//*[@id=\"content-navigation\"]/div/div/div/div/div/div[4]/nav/div/div[3]/a")).click();
String hp=dr.findElement(By.xpath("//*[@id=\"top-of-content\"]/div/div[3]/div/div/div[2]/section[1]/div[3]/div/div[1]/div/table/tbody/tr[4]/td[2]/div")).getText();	
System.out.println("horespower:"+hp);	
int lhp=hp.length();
System.out.println(lhp);
String aph=hp.substring(5,8);
System.out.println(aph);
int hp1=Integer.parseInt(aph);
System.out.println(hp1);

return hp1;
	
	}
}





