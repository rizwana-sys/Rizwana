package bmw1_hp;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class NewTest {
	WebDriver dr;
	classjava ph;
	String url="https://www.bmw.in/en/";
@BeforeClass
public void launchbrowser()
{
	ph=new classjava(dr);
	dr=ph.launchbrowser("CHROME",url);
}
  @Test
  public void f() {
	  int num=ph.page1();
	  ph.page1();
	  boolean b;
	  if(num<500)
	  {
		  b=false;
		  System.out.println("does not meeet");
	  }
		  else
		  {
			b=true;  
		  }
		  Assert.assertTrue(b);
	  }
	  
  }

