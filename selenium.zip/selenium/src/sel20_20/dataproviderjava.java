package sel20_20;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class dataproviderjava {
	 public String login(String eid,String pwd)
	  {
	
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	
	dr.findElement(By.linkText("Log in")).click();
	dr.findElement(By.id("Email")).sendKeys(eid);
	dr.findElement(By.id("Password")).sendKeys(pwd);
	dr.findElement(By.xpath("//input[@value='Log in']")).click();
	String a_eid=dr.findElement(By.xpath("//div[@class='header-links']//following::a")).getText();
	
	return a_eid;
}
}
