package sel20_20;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class draggable {
	static WebDriver driver;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		String URL="https://demoqa.com/droppable/";
		driver.get("http://demowebshop.tricentis.com/login");
		driver.manage().window().maximize();
		Actions builder=new Actions(driver);
		WebElement from=driver.findElement(By.id("droggable"));
		WebElement to=driver.findElement(By.id("droppable"));
		builder.dragAndDrop(from,to).perform();
		String textTo=to.getText();
		if(textTo.equals("Dropped")){                                              
			System.out.println("pass:succesful");
		}
		else{
			System.out.println("fail:not succesful");
		}
	}

}
