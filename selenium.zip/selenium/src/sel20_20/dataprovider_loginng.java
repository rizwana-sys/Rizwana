package sel20_20;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_loginng {
	dataproviderjava obj=new dataproviderjava();
	
	
  @Test(dataProvider="login_data")
  
  public void login(String eid,String pwd,String exp_eid)
  {
	  String a_eid=obj.login(eid,pwd);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(a_eid, exp_eid);
	  sa.assertAll();
  }
  @DataProvider(name="login_data")
  
  public String[][] provide_data()
  {
	  String[][] data={
			  {"rizzu5399@gmail.com","Rizwana@19","rizzu5399@gmail.com"},
			  {"rizzu5399@gmail.com","rizwana@19","rizzu5399@gmail.com"},
	 };
	 return data; 
  }
  
  
}
