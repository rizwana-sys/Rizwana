package sel20_20;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class page {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		Actions kb=new Actions(dr);
		kb
		.sendKeys(Keys.PAGE_DOWN)
		.sendKeys(Keys.PAGE_UP)
		.build()
		.perform();
		
	}
}
