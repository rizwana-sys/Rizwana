package sel20_20;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dataprov_excel_cls {
	public static String filename="C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\new data.xlsx",
	                     sheetname="login_data";
	public static String[][] testdata;
	public static int r_no,c_no;
	public static void get_Test_data(){
		testdata=new String[2][3];
		int c;String s=null,s1=null,s2=null;
		for(r_no=0;r_no<=1;r_no++)
		{
			try
			{
		System.out.println("in get test data row="+ r_no);
		File f= new File(filename);
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet =wb.getSheet(sheetname);
		XSSFRow row=sheet.getRow(r_no);
		XSSFCell cell1=row.getCell(0);
		testdata[r_no][0]=cell1.getStringCellValue();
		System.out.println("row 1:"+testdata[r_no][0]);
		XSSFCell cell2=row.getCell(1);
		testdata[r_no][1]=cell2.getStringCellValue();
		System.out.println("row 1:"+testdata[r_no][1]);
		XSSFCell cell3=row.getCell(2);
		testdata[r_no][2]=cell3.getStringCellValue();
		System.out.println("row 1:"+testdata[r_no][2]);
		
					
	}
			catch(FileNotFoundException e){
				e.printStackTrace();
				}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}

	  public String login(String eid,String pwd)
	  {
			System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");

		     WebDriver dr=new ChromeDriver();
		   	dr.get("http://demowebshop.tricentis.com");
			  String act_res;
		   
			dr.findElement(By.xpath("//div[@class='header-links-wrapper']//child::li[2]/a")).click();
			dr.findElement(By.xpath("//div[@class='form-fields']//child::div[2]/input")).sendKeys(eid);
		  	dr.findElement(By.xpath("//div[@class='form-fields']//child::div[3]/input")).sendKeys(pwd);
		     dr.findElement(By.xpath("//input[contains(@value,'Log')]" )).click();
		     try{
		    	   act_res=dr.findElement(By.xpath("//span[@for='Email']")).getText();
		  
		     }catch (org.openqa.selenium.NoSuchElementException e) {
		    	 try{
		    		  act_res=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
		    	 }
		    	 catch(org.openqa.selenium.NoSuchElementException e1){
				
		     act_res=dr.findElement(By.xpath("//a[@class='account']")).getText();
				
		    	 }
		     }
			return act_res;
	  }
	}