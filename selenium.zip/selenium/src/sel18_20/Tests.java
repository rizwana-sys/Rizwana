package sel18_20;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class Tests{
	
	WebDriver dr;
	public void login()
	{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
public Tests(WebDriver dr)
{
	this.dr=dr;
}
}
