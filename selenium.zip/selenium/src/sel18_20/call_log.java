package sel18_20;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class call_log {
	
WebDriver dr;

Tests obj;

@BeforeMethod
public void BM()
{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr=new ChromeDriver();
	dr.get("https://www.saucedemo.com/");
	obj=new Tests(dr);
}


  @Test
  public void f() {
	  obj.login();
  }
}
