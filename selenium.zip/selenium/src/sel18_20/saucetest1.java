package sel18_20;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import selenium.sauce;

public class saucetest1 {
	WebDriver dr;
	saucejava1 obj;
	int[] i ={1,2};
	int c=0;
  @Test
  public void first() {
	  
	  obj.verify(1);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(obj.exp_name1,obj.act_name1);
	  sa.assertEquals(obj.e_p1,obj.ap1);
	  sa.assertAll();
  }
  
  @Test
  public void Second() {
	  
	  obj.verify(2);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(obj.exp_name1, obj.act_name1);
	  sa.assertEquals(obj.e_p1,obj.ap1);
	  sa.assertAll();
      }
  
  @BeforeMethod
  public void beforeMethod() 
  {
	  obj.addpd(i[c]);
	  c++;
  }  
@AfterMethod
  public void afterMethod() {
	  if(c<2)
	  {
	  obj.Add_info();
	 
	  }
  }
 @BeforeClass
	 public void beforeClass()
	 {
	 System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr = new ChromeDriver();
	dr.get("https://www.saucedemo.com/");
	dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	obj = new saucejava1(dr);
	obj.login("standard_user", "secret_sauce");
	 }
public void afterClass()
{
	  
	  obj.Add_info();
	  obj.thankYouMsg();
	  dr.close();
}

}














