package sel_28_20;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Date_picker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   String exp_mon_year="April 2020";
   int  exp_date=20;
   System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr=new ChromeDriver();
   dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
String cur_mon_y=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	while(!exp_mon_year.equals(cur_mon_y))
	{
		dr.findElement(By.xpath("//a[@class='ui-datepicker-next ui-corner-all']//span")).click();
       cur_mon_y=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
}
	
List<WebElement> all_dates=dr.findElements(By.xpath("//td[@class='ui-datepicker-current-day']"));
	for(WebElement ele:all_dates)
	{
		String date=ele.getText();
		
		if(ele.equals("19"))
			{
			ele.click();
			break;
			}
	}
	}

}
