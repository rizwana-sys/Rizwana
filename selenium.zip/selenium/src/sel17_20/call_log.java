package sel17_20;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class call_log {
	
	
	Test_log obj;
	@BeforeMethod
	public void BeforeMethod()
	{
		obj=new Test_log();
	}
  @Test
  public void f() {
	  obj.login();
  }
}
