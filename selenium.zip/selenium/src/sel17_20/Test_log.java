package sel17_20;

public class Test_log {
	public void login()
	{
		System.out.println("log in successful");
	}

}
