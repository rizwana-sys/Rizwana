package sel17_20;

import org.apache.log4j.Logger;

public class log_file {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
Logger log=Logger.getLogger("devpinoyLogger");
log.debug("Error happend");

log.info("info msg");
	}

}
