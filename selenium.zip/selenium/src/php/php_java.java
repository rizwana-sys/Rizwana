package php;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class php_java
{
WebDriver dr;
public php_java(WebDriver dr)
{
this.dr=dr;	
}
public WebDriver launchbrowser(String browser,String url)
{
	if(browser.contains("CHROME"))
	{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr=new ChromeDriver();
	}
	else if(browser.contains("FIREFOX"))
	{
		System.setProperty("Webdriver.gecko.driver","geckodriver.exe");
		dr=new FirefoxDriver();
	}
	dr.get(url);
	return dr;
}
public void page1()
{
dr.findElement(By.xpath("//*[@id=\"dropdownCurrency\"]")).click();
dr.findElement(By.xpath("//*[@id=\"header-waypoint-sticky\"]/div[1]/div/div/div[2]/div/ul/li[1]/div/div/div/a[4]")).click();

	try {
		Thread.sleep(600);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
dr.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/div[3]/div/div/div/div/div/nav/ul/li[2]/a")).click();




//dr.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).click();
//dr.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).sendKeys("Los Angeles");
//dr.findElement(By.xpath("//*[@id=\"s2id_location_from\"]/a/span[1]")).click();
//
//
//
//dr.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).click();
//dr.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).sendKeys("Dallas");
//dr.findElement(By.xpath("))

//dr.findElement(By.xpath("//*[@id=\"select2-drop\"]/div/input")).sendKeys("Dallas Fortworth(DFW");
//String price=dr.findElement(By.id("//*[@id=\"FlightsDateStart\"]")).getText();
//System.out.println("price");
//int p1=Integer.parseInt(price);
//System.out.println(p1);
//return p1;
}
}





