package php;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class php_testng {
	WebDriver dr;
	php_java php;
	String url="https://www.phptravels.net/home";
	@BeforeClass
	public void launchbrowser()
	{
		php=new php_java(dr);
		dr=php.launchbrowser("CHROME", url);
	
	}
  @Test
  public void f() 
  {
	 //int num=
	  php.page1();
//	 php.page1();
//	 boolean b;
//	  if(num>100 && num<250)
//	  {
//		  b=true;
//		  Assert.assertTrue(b);
	//  }
		//  else
		  //{
			//  b=false;
		  //}
	  //System.out.println("does ")
 // }
  }
}

