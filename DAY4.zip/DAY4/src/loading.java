
public class loading {
	public int add(int x,int y)
	{
		int z=x+y;
		System.out.println("2 same parameters");
		return z;
	}
	public int add(int a,int b,int c,int e,int f)
	{
		int d= a+b+c+e+f;
		System.out.println("5 parameters");
		return d;
	}
	public static void main(String[] args)
	{
		loading  calc=new loading();
		int m=calc.add(2,3);
		int m1=calc.add(2,3,4,7,8);
		System.out.println(m);
		System.out.println(m1);
	}

}
