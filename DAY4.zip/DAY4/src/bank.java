
public class bank {
	public float get_roi()
	{
		return 0f;
	}
	public void show()
	{
		System.out.println("Bank details");
	}

}
