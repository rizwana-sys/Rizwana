

public class student {
		int id;
		String  name;
		int selinium;
		int java;
		float avg;
		public student(int i, int j) {
			// TODO Auto-generated constructor stub
		}
		public void student(int selinium,int java)
		{
			System.out.println("object created");
			this.java=java;
			this.selinium=selinium;
		}
		public void calc_avg(){
			avg=(selinium+java)/2.0f;
		}
					}
