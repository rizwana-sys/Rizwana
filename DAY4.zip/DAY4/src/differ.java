import java.util.ArrayList;


public class differ {
public static void main(String[] args)
{
	
ArrayList<>=Str_al=new ArrayList<>();
Str_al.add("asf");
int.add(1);

}
