import java.util.ArrayList;


public class arraylist {
	public static void main(String [] args)
	{
		ArrayList<String >Str_al=new ArrayList<String>();
		Str_al.add("asf");
		Str_al.add("rakesh");
		Str_al.add("himanshu");
		Str_al.add("suresh");
		System.out.println("before insertion:"+Str_al);
		Str_al.add(2,"priya");
		System.out.println("after insertion:"+Str_al);
		Str_al.remove("asf");
		System.out.println("after deletion:"+Str_al);
		Str_al.remove(1);
		System.out.println("after deletion:"+Str_al);
		Str_al.add(3,"selva");
		System.out.println("after insertion:"+Str_al);
		for(String S:Str_al)
		{
			System.out.println(S);
		}
}
}
