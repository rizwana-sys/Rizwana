import java.util.Scanner;


public class array {
	public class intos {

		String[][] std = {{"1","rizwana"},{"2","Divya"}, {"3","pallavi"},{"4","Priyanka"}, {"5","Pooja"}};
	    static  int[][] marks={{1,95,97,0},{2,56,93,0},{3,47,85,0},{4,98,95,0},{5,65,58,0}};
	    int  i,id,index=0;
		int j; 
	    public int calc_avg( int k)
	    {
	    	int avg;
	    	avg=(marks[k][1]+marks[k][2]/2);
	    	System.out.println(avg);
	    }
	    public int search(int string)
	    {
	    	for(i=0;i<5;i++)
	    	{
	      string=Integer.parseInt(std[i][0]);
	    	if(string==marks[i][0])
	    	{
	    		index=i;
	    		break;
	    	}
	    	return index;
		}
	    }
	}
	
		public static void main(String[] args)
		array obj=new array();
		System.out.println("id"+"name"+"avg");
		{
		 j=search("11");
		 avg=calc_avg(j);
		 
		 System.out.println("id"+"name"+"avg"+"j");
		
		}


}
