package testfactory_java;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AutoLogin{
	WebDriver dr;
	@FindBy(xpath="//input[@type='text']")
   WebElement username;
   @FindBy(xpath="//input[@type='password']")
   WebElement pwd;
   @FindBy(xpath="//input[@type='submit']")
WebElement btn;
public AutoLogin(WebDriver dr)
{
	this.dr=dr;
	PageFactory.initElements(dr,this);
}
public void set_username(String un)
{
	username.sendKeys(un);
}
public void set_pwd(String pword)
{
	pwd.sendKeys(pword);
}
public void clk_btn()
{
	btn.click();
}
	 public  void do_login(String un, String pword)
{
	this.set_username(un);
	this.set_pwd(pword);
	this.clk_btn();
}
public String get_title()
{
	return dr.getTitle();
}
}



