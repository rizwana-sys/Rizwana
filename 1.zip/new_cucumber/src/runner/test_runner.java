package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@CucumberOptions(features="FEATURE",glue="step_def")
public class test_runner  extends AbstractTestNGCucumberTests{
	

}
