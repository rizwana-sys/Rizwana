package step_def;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class copy1 {
	WebDriver dr;

@Given("^Browser is launched and displayed$")
public void browser_is_launched_and_displayed() throws Throwable {
	 System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");    
}

@When("^user selects the book$")
public void user_selects_the_book() throws Throwable {
	dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select/option[4]")).click();
}

@Then("^verify which book is selected$")
public void verify_which_book_is_selected() throws Throwable {
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
}

}
