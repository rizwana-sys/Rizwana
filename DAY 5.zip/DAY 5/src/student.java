

public class student {
		int id;
		String  name;
		int selinium;
		int java;
		int  avg;
		public student(String name,int id,int java,int selinium)
		{
		this.name=name;
		this.id=id;
		this.java=java;
		this.selinium=selinium;
}
		public void calc_avg()
		{
			avg=(selinium+java)/2;
					}


}
