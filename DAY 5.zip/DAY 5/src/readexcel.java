import java.io.File;
import java.io.FileInputStream;




public class readexcel
{
		public String readexcel(String filename,String sheetname,int c,int r) 
	{
       String s=null;
       File f=new File(filename);
       FileInputStream fis=new FileInputStream(f);
       XSSFWorkbook wb=new XSSFWorkbook(fis);
       
}
public static void main(String[] args)
{
	readexcel k=new readexcel();
			String s=k.readexcel("C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\javaxl\\readnew.xlsx");
	System.out.println(s);
}