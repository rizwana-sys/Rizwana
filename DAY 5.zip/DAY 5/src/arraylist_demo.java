import java.util.ArrayList;


public class arraylist_demo {
	ArrayList<student> std_al=new ArrayList<student>();
	
	public void create_al()
	{
		student s1=new student("ramesh",101,80,90);
		student s2=new student("ramesh1",102,85,98);
		std_al.add(s1);
		std_al.add(s2);
	}
	public void display_al()
	{
		for(student s: std_al)
		{
			System.out.println("name:"+s.name
					            +"id:"+s. id 
					            +"sel marks:" +s.selinium 
					            +"java marks:"+s.java 
					            +"avg:"+s.avg);
		}
	}

public static void main(String[] args)
{
	arraylist_demo al=new arraylist_demo();
	al.create_al();
	al.display_al();
}
}