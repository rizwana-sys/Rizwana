
public class prime {
	public static void main(String [] args)
	{
		
		int i,n,count,rem=0;
		for(n=1;n<=50;n++)
		{
			count=0;
			for(i=2;i<=n;i++)
			{
				rem=n%i;
				if(n%i==0)
				{
					count++;
					break;
				}
				if(count==2)
				{
					System.out.println("prime");
				}
				else
				{
					System.out.println("not prime");
				}
		}
		}
	}
}
