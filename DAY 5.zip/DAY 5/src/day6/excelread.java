package day6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelread {
	
	public String readexcel(String filename,String sheetname,int r,int c)
	{
	String s = null;
	{
		File f=new File(filename);
	try {
		FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb =new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sheetname);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.getCell(c);
			s=cell.getStringCellValue();
			
			cell.setCellValue("chennai");
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
	}
			 catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			 }
				catch(IOException e)
				{
					e.printStackTrace();
				}
		return s;
	}
	}
	
public static void main(String[] args) {
		// TODO Auto-generated method stub
	excelread s1=new excelread();
	String k=s1.readexcel("");
	System.out.println(k);

	}

}
