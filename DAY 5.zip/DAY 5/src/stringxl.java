import java.io.FileInputStream;
import java.io.IOException;


public class stringxl {
public static void main(String [] args)
{
	try
	{
		FileInputStream fin=new FileInputStream("C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\javaxl\\string.txt");
		int i;
		while((i=fin.read())!=-1)
		{
			System.out.println((char)i);
		}
		fin.close();
		}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}
}
