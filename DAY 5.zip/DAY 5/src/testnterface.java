
public class testnterface {
	public static void main(String[] args)
	{
		drawable d=new rectangle();
		d.draw();
	}

}    
