import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class stringxl1 {
	
	public static class stringxl {
		public  static void main(String [] args)
		{
			try
			{
				FileInputStream fin=new FileInputStream("C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\javaxl\\string.txt");
				int i;
				while((i=fin.read())!=-1)
				{
					System.out.println((char)i);
				}
				fin.close();
FileOutputStream fos=new FileOutputStream("C:\\Users\\BLTuser.BLT0204\\Desktop\\cts\\javaxl\\string.txt");
byte[]d="java".getBytes();
fos.write(d);
fos.close();
				}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		}
}
