
public interface drawable {
	void draw();

}
