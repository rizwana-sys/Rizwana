package day6;

public class eveninodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []num={18,2,99,23,

	}

}
