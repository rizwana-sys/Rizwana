package testfactory_java;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Autohome_page {
	WebDriver dr;
	@FindBy(xpath="//div[@class='product_label']")
			WebElement protitle;
	
	public Autohome_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr,this);
	}
	public String get_displayed()
	{
		return protitle.getText();
	}
}


