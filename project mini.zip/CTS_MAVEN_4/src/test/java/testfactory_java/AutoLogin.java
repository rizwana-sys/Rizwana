package testfactory_java;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AutoLogin{
	WebDriver dr;
	@FindBy(xpath="//input[@type='text']")
   WebElement username;
   @FindBy(xpath="//input[@type='password']")
   WebElement pwd;
   @FindBy(xpath="//input[@type='submit']")
WebElement btn;
   
   @FindBy(xpath="//*[@id=\"inventory_filter_container\"]/select")
   WebElement a_to_z;
   
   
   @FindBy(xpath="//button[@style='position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; margin: 0px; padding: 0px;"
   		+ " border: none; opacity: 0; font-size: 8px; cursor: pointer;']")
   WebElement menu;
   
   
   
   
   @FindBy(xpath="//*[@id=\"about_sidebar_link\"]")
   WebElement about;
   
   @FindBy(xpath="//*[@id=\"headerMainNav\"]/div/nav/ul/li[1]/ul[2]/li[6]/div[1]/div/a")
   WebElement contact;
   
public AutoLogin(WebDriver dr)
{
	this.dr=dr;
	PageFactory.initElements(dr,this);
}
public void set_username(String un)
{
	username.sendKeys(un);
}
public void set_pwd(String pword)
{
	pwd.sendKeys(pword);
}
public void clk_btn()
{
	btn.click();
}

public void clk_a_to_z()
{
	a_to_z.click();
}

public void clk_menu()
{
	menu.click();
}

public void clk_about()
{
	about.click();
}

public void clk_contact()
{
	contact.click();
}



	 public  void do_login(String un, String pword)
{
	this.set_username(un);
	this.set_pwd(pword);
	this.clk_btn();
	this.clk_a_to_z();
	this.clk_about();
	this.clk_contact();
}
public String get_title()
{
	return dr.getTitle();
}
}



