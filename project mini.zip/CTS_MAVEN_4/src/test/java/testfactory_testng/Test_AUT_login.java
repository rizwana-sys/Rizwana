package testfactory_testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import testfactory_java.AutoLogin;
import testfactory_java.Autohome_page;

public class Test_AUT_login {
	WebDriver dr;
	 AutoLogin login;
	 Autohome_page homepage;
	 
@BeforeClass
public void launchBrowser()
{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
     dr = new ChromeDriver();
  dr.get("https://www.saucedemo.com/");
}

@Test(priority=1)
	public void AutoLogin()
	{
	login=new AutoLogin(dr);
	String login_page_title=login.get_title();
	Assert.assertTrue(login_page_title.contains("Swag"));
}
	@Test(priority=2)
	public void Autohome_page()
	{
		homepage=new Autohome_page(dr);
		login.do_login("standard_user","secret_sauce");
	String actual_un=homepage.get_displayed();
	   Assert.assertTrue(actual_un.contains("Products"));
	}
	}
	
