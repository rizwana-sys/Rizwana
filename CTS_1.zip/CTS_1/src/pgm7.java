
public class pgm7 {
	public static void main(String [] args)
	{
		int a=10,b=0,c;
		int[] m={1,2,3,4,5};
		try
				{
            c=a/b;
            System.out.println(m[3]);
				}
		catch(ArithmeticException  ae)
		{
			System.out.println("catch of ArithmeticException ");
		}
		
		System.out.println("outside catch");
			
}

}
