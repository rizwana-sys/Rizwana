package DAY_1;

public class pgm4 {
	public static void main(String [] args)
	{
int a=10,b=20,c=30;
if(a<b)
{
	if(a<c)
	{
	System.out.println(a +" is smallest");
}
	else
	{
		System.out.println(c+" is smallest");
	}
if(b<c)
{
	System.out.println(b+" is smallest");
}
	else
	{
		System.out.println(c+" is smallest");
	}
	
}
}
}
