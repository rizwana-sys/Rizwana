package DAY_1;

public class pgm18 {
public static void main(String[] args)
{
	int sum=0,n=1234,r;
	while(n>0)
	{
		r=n%10;
		sum=r+(sum*10);
		
	}
}
}
