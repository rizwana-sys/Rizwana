package DAY_1;

public class pgm5 {
	public static void main(String [] args)
	{
		float sal=950000;
		float tax;
		if(sal<180000)
		{
			
			tax=(180000-sal);
			System.out.println("zero tax"+tax);
		}
	if(sal>180000 && sal<=500000)
		{
		tax=(500000-sal)*0.1f;
			System.out.println("10 percent tax "+tax );
		}
if(sal>500000 && sal<=800000)
{
	tax=(800000-sal)*0.2f;
	System.out.println("20 percent tax"+tax );
}
if(sal>800000 && sal<=1000000)
{
	tax=(1000000-sal)*0.3f;
			System.out.println("30 percent tax"+tax );
}
	}
}

