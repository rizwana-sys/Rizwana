package DAY_1;

public class pgm10 {
	public static void main(String [] args)
	{
	int  i,sum=0,rem,n=59138;
	for(i=5;i<=n;i++)
		{
		 rem=n%10;
			sum=sum+rem;
			n=n/10;
			System.out.println(sum);
			
		}
	}
	}
