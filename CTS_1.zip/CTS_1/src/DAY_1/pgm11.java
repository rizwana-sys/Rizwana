package DAY_1;

public class pgm11 {
	public static void main(String [] args)
	{
		int i,num=7;
		for(i=1;i<=10;i++)
			{
				System.out.println("i,num*i");
			}
			
			
	}

}
