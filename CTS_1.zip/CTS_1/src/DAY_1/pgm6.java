package DAY_1;

public class pgm6 {
	public static void main(String [] args)
	{
	int i=70;
	switch(i)
	{
	case 10:System.out.println("ten");
	       break;
	case 20:System.out.println("twenty");
	       break;
	case 30:System.out.println("thirty");
	       break;
	default:System.out.println("invalid");
break;
	case 40:System.out.println("fourty");
	       break;
	case 50: System.out.println("fifty");
	       break;
	}
	
	}

}
