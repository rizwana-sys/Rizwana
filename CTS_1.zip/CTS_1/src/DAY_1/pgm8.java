package DAY_1;

public class pgm8 {
	public static void main(String [] args)
	{
		int i=0,n=1234,sum=0;
		while(n>0)
		{
			 int r=n%10;
			 sum=sum+r;
			 n=n/10;
			 System.out.println("sum is "+sum);
			
		}
		
	}

}
