package DAY_1;

public class pgm7 {
	public static void main(String [] args)
	{
		int i,n=10;
		int rem;
		for(i=1;i<=10;i++)
		{
			rem=n%2;
			if(rem==0)
				System.out.println(i);
		}
				
	}

}
