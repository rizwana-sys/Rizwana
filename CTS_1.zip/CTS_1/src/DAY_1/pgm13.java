package DAY_1;

public class pgm13 {
	public static void main(String [] args)
	{
		
	}

}
