package DAY2;

public class PGM1 {
	public static void main(String[] args)
	{
		int[] marks={85,81,80,70,70,65,71,80};
		 float sum=0;
		 float avg;
		for( int i=0;i<=7;i++)
		{
			sum=sum+marks[i];
		}
		avg=sum/8.0f;
			System.out.println("sum is"+sum);
			System.out.println(" avg is"+avg);
			if(avg>=70)
			{
				System.out.println("first class with distinction");
			}
			if(avg<70 && avg>=60)
			{
				System.out.println("second class");
			}
			if(avg<=60 && avg>=45)
			{
				System.out.println("third class");
			}
			if(avg<45 && avg>=35)
			{
				System.out.println("pass");
			}
			if(avg<35)
			{
				System.out.println("fail");
			}
	
}
}