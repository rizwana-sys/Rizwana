package DAY2;

public class pgm11 {
	public static void main(String[] args)
    {
int n=0,count=0,p=0;
     String s="Hello, how are you?";
while(p!=-1)
     {
          p=s.indexOf("o",n);
count++;
         n=p+1;
     }
System.out.println(count-1);
    }
}
