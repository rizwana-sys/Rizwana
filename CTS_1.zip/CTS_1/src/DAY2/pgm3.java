package DAY2;

public class pgm3 {
	public static void main(String[] args)
	{
		int r,c,s=0;
		int[][] m={{75,85,80},{81,91,95}};
		for( r=0;r<=1;r++)
		{
			for(c=0;c<=2;c++)
			{
				if(m[r][c]%2==0)
					s=s+m[r][c];
			}
		}
			System.out.println(s);
		}
	}

