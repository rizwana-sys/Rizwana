package DAY2;

public class pgm5 {
	public static void main(String [] args)
	{
		int i=0,p=0,c=0;
		String s="I am learning core java";
		while(p>=0)
		{
			p=s.indexOf(" ",i);
			i=p+1;
			c++;
		}
	c=c-1;
			System.out.println(c);
		}
	}