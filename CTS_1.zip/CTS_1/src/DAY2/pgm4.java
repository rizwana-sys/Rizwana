package DAY2;

public class pgm4 {
	public static void main(String [] args)
	{
		String s="chennai",s1="pune",s2="chennai",s3;
		int l=s.length();
		int v=s.compareTo(s1);
		System.out.println("length=" + "Return value :"+v);
		int rv=s.compareToIgnoreCase(s2);
				System.out.println("rv="+rv);
				s3=s.substring(0,4);
				System.out.println("substring:"+s3);
				int p=s.indexOf("n",0);
				System.out.println("position:"+p);
				int p1=s.indexOf("n",p+1);
				System.out.println("position of 2nd: " +p1);
			
	}

}
