package DAY2;

public class pgm2 {
	public static void main(String [] args)
	{
		int marks[]={95,91,85,86,90,77,71,81};
		int odd,even,sum=0;
		for( int i=0;i<7;i=i+2)
		{
			if(marks[i]%2!=0)
		{
			sum=sum+marks[i];
		}
	}
		System.out.println(sum);
	}
}
