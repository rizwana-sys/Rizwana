package DAY2;

public class pgm8 {
	public static void main(String[] args)
	{
		int largest=8,r,max;
		int[]m={8,99,23,18};
		for(r=0;r<=2;r++)
		{
			if(largest<m[r])
			{
				largest=m[r];
			}
				System.out.println(" max in row is:"+largest);
			}
	}
	}
