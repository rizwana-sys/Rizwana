
public class pgm6 {
	public static void main(String [] args)
	{
		String s="i am learning core java";
		int p=0,i=0,c=0;
		while(p!=-1)
		{
			(-1)p=s.indexOf(" ",i);
			if(p==-1)
				p=s.length();
			c++;
			s1=s.substring(i,p);
			i=p+1;
			System.out.println("i="+i+"p="+p);
			
		}
		
	}

}
