package DAY3;

import java.util.Scanner;

public class pgm1 {
public static void main(String[] args)
{ 
	int count=0;
	System.out.println("Enter a String:");
	Scanner input=new Scanner(System.in);
	char c=input.next().charAt(0);
	while(c!='N'&& c!='n')
	{
	
		if(c=='A'||c=='a'||c=='E'||c=='e'||c=='I'||c=='i'||c=='O'||c=='o'||c=='U'||c=='u')	
		{
		count++;
		}
			 c=input.next().charAt(0);
	}
	System.out.println("count="+count);
	}
}

