package DAY3;

public class student {
		int id;
		String  name;
		int selinium;
		int java;
		float avg;
		public void calc_avg()
		{
			avg=(selinium+java)/2.0f;
					}


}
