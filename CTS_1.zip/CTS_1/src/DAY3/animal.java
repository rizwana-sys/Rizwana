package DAY3;

public class animal {
	int height,weight,age;
	String color;
	char gender;
		public void display()
		{
		System.out.println("height:"+ height + "weight:"+weight + "age:"+ age  + "color:"+color  +"gender:"+gender);
		}
	}
