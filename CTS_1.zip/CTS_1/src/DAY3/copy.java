package DAY3;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class copy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File()
		try
		{
			String f;
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh2=wb.getSheet("Sheet2");
			XSSFRow r=sh2.getRow(0);
			XSSFCell cell=r.getCell(0);
}
	}
