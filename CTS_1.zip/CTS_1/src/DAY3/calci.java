package DAY3;

public class calci  extends library{
	public static void main(String[] args)
	{
	calci c=new calci();	
	float d=c.add(3, 5.0f);
	System.out.println("addition:"+d);
	}

}
