package DAY3;

public class basiccalc {
int num1,num2;
basiccalc c=new basiccalc();	
int  d=c.add(3, 5);
System.out.println("addition:"+d);
}
