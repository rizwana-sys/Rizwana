package DAY3;

import java.util.Scanner;

public class stringemp {
	public static void main(String[] args)
	{
		String[][] S={{"1","ram"},{"2","sam"},{"3","rani"},{"4","raju"},{"5","ranga"}};
		int i,j=0,k;
		String empid;
		Scanner n=new Scanner(System.in);
		empid=n.next();
		for(i=0;i<5;i++)
		{
			k=S[i][j].compareTo(empid);
			if(k==0)
			{
				System.out.println(S[i][j+1]);
			}
		}
	}
}
