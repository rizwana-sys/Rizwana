package DAY3;

public class zoo {
public static void main(String[] args)
{
	elephant el=new elephant();
	el.height=2;
	el.weight=250;
	el.age=10;
	el.color="grey";
	el.gender='f';
	el.display();
	
}	
}
