package DAY3;

public class college {
	public static void main(String[] args)
	{
		student rizwana=new student();
		rizwana.java=80;
		rizwana.selinium=90;
		rizwana.calc_avg();
		System.out.println("avg marks of rizwana="+rizwana.avg);
		
		student priya=new student();
		priya.java=90;
		priya.selinium=90;
		priya.calc_avg();
		System.out.println("avg marks of priya="+priya.avg);
	}

}
