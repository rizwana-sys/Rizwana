package DAY3;

public class elephant extends animal {
	int lotusk,lotrunk;
	public void display_details()
	{
		super.display();
		System.out.println("lotusk :"+ lotusk + "lotrunk:" + lotusk);
	}
}
