package STEP_DEF_PKG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class copy {
	
	WebDriver dr;
	String test_result;

@Given("^Browser is launched & login page displayed$")
public void browser_is_launched_login_page_displayed() throws Throwable {
   System.out.println("Browser is launched & login page displayed");
   System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com"); 
}

@When("^User enters login crendentials & clicks on login$")
public void user_enters_login_crendentials_clicks_on_login() throws Throwable {
 System.out.println("User enters login crendentials & clicks on login"); 
 dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("rizzu5399@gmail.com");
	dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("rizwana@19");
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click(); 
}

@Then("^Successful login happens & profile name displayed correctly$")
public void successful_login_happens_profile_name_displayed_correctly() throws Throwable {
    System.out.println("Successful login happens & profile name displayed correctly");
   // String e_eid="rizzu5399@gmail.com";
   // String e_title="Demo Web Shop";
    String title=dr.getTitle();
   String  actEid=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
    
    if(title.equals("Demo Web Shop") && actEid.equals("rizzu5399@gmail.com"))
    {
    	test_result="pass";
    }
    else
    {
    	test_result="fail";
    }
    
}
}
